// This is to implement the head file.

#include <DigDisplay.h>

DigDisplay::DigDisplay(int terminals[]) {
    for (int i = 0; i<12; i++) {
        this->terms[i] = terminals[i];
        pinMode(terminals[i], OUTPUT);
    }
    this->digits[0] = terminals[0];
    this->digits[1] = terminals[3];
    this->digits[2] = terminals[4];
    this->digits[3] = terminals[11];
}

void DigDisplay::disp(int n, bool dot) {
    //If you want this display show the number all the time, you have to call this function all the time.
    while (n > 9999) n = n - 10000;
    
    //determine whether to light up the dots in the middle.
    if (dot) {
        digitalWrite(this->terms[8], LOW);
    }else{
        digitalWrite(this->terms[8], HIGH);
    }

    //start to display the digits
    int s = n;
    for (int i = 0; i < 4; i++) {
        digitalWrite(this->digits[i], HIGH);
        switch (s % 10) {
            case 0:
                digitalWrite(this->terms[10], HIGH);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], LOW);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;
            case 1:
                digitalWrite(this->terms[10], HIGH);
                digitalWrite(this->terms[9], HIGH);
                digitalWrite(this->terms[7], HIGH);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], HIGH);
                break;
            case 2:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], HIGH);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], LOW);
                digitalWrite(this->terms[2], HIGH);
                digitalWrite(this->terms[1], LOW);
                break;
            case 3:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], HIGH);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;
            case 4:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], HIGH);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], HIGH);
                break;
            case 5:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], HIGH);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;                
            case 6:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], HIGH);
                digitalWrite(this->terms[5], LOW);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;                
            case 7:
                digitalWrite(this->terms[10], HIGH);
                digitalWrite(this->terms[9], HIGH);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], HIGH);
                break;
            case 8:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], LOW);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;
            case 9:
                digitalWrite(this->terms[10], LOW);
                digitalWrite(this->terms[9], LOW);
                digitalWrite(this->terms[7], LOW);
                digitalWrite(this->terms[6], LOW);
                digitalWrite(this->terms[5], HIGH);
                digitalWrite(this->terms[2], LOW);
                digitalWrite(this->terms[1], LOW);
                break;                
        }
        s = s / 10;
        delay(2);
        
        //Reset all the pins to shut all the segmanets.
        digitalWrite(this->digits[i], LOW);
        digitalWrite(this->terms[10], HIGH);
        digitalWrite(this->terms[9], HIGH);
        digitalWrite(this->terms[7], HIGH);
        digitalWrite(this->terms[6], HIGH);
        digitalWrite(this->terms[5], HIGH);
        digitalWrite(this->terms[2], HIGH);
        digitalWrite(this->terms[1], HIGH);
    }
}